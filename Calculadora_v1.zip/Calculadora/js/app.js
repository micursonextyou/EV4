

/* definicion de variable contenedora de numeros */
var pantalla=document.getElementById("display"); // Variable de la pantalla

var NUMEROS_INGRESADOS="";


var Expre="";



/*  fin declaracion */


/* declaracion de oyente de enventos click sobre numeros */



document.getElementById("0").addEventListener("click", ingresar_numeros);
document.getElementById("1").addEventListener("click", ingresar_numeros);
document.getElementById("2").addEventListener("click", ingresar_numeros);
document.getElementById("3").addEventListener("click", ingresar_numeros);
document.getElementById("4").addEventListener("click", ingresar_numeros);
document.getElementById("5").addEventListener("click", ingresar_numeros);
document.getElementById("6").addEventListener("click", ingresar_numeros);
document.getElementById("7").addEventListener("click", ingresar_numeros);
document.getElementById("8").addEventListener("click", ingresar_numeros);
document.getElementById("9").addEventListener("click", ingresar_numeros);

/* fin de oyente de click sobre numeros */


/* declaracion de oyente de enventos click sobre singo */

document.getElementById("on").addEventListener("click", ingresar_numeros);
document.getElementById("sign").addEventListener("click", ingresar_numeros);
document.getElementById("igual").addEventListener("click", ingresar_numeros);
document.getElementById("punto").addEventListener("click", ingresar_numeros);

/* fin  declaracion de oyente de enventos click sobre singo */

/* declaracion de oyente de enventos click sobre operacion */

document.getElementById("mas").addEventListener("click", ingresar_numeros);
document.getElementById("menos").addEventListener("click", ingresar_numeros);
document.getElementById("por").addEventListener("click", ingresar_numeros);
document.getElementById("raiz").addEventListener("click", ingresar_numeros);
document.getElementById("dividido").addEventListener("click", ingresar_numeros);

/* fin declaracion de oyente de enventos click sobre operacion */


/* 
	esta funcion captura los eventos  click sobre lo elementos, y devuelve el ID cada elemento
	el cual se usa para asigna numeros.

*/
function ingresar_numeros(evt){
	
		switch (this.id) {

/* casos de operacions ---- en esta seccion  invocamos funciones de operaciones */
			case "mas":			
				//
				Expre+="+";
				NUMEROS_INGRESADOS="";
													
				break;

			case "menos":
				Expre+="-";
				NUMEROS_INGRESADOS="";						
																		
				break;

			case "por":
				Expre+="*";
				NUMEROS_INGRESADOS="";					
															
				break;
			case "dividido":		
				Expre+="/";
				NUMEROS_INGRESADOS="";
				
				break;
			case "raiz":

				var dd=Math.sqrt(NUMEROS_INGRESADOS);
				document.getElementById("resultado").innerHTML=dd;
				break;


/* casos tipo especiales */	
			case "on":			
				NUMEROS_INGRESADOS="";
				Expre="";											
				break;

			case "punto":									
					NUMEROS_INGRESADOS=NUMEROS_INGRESADOS+'.';																
				break;

			case "igual":

				total();
				

				
															
				break;
			case "sign":			
				if(NUMEROS_INGRESADOS.indexOf("-")!=-1){
					var numero_sin_singo=NUMEROS_INGRESADOS;
					var signo="-";
					NUMEROS_INGRESADOS=numero_sin_singo.replace(signo,'');
				} else { 
					if(NUMEROS_INGRESADOS !==""){
						
						NUMEROS_INGRESADOS="-"+NUMEROS_INGRESADOS;
					}
					
				}
				break;


	/* casos tipo numero agrega en el span pantalla los numero ingresados hast 9 caracteres */			
			case "0":
				NUMEROS_INGRESADOS=NUMEROS_INGRESADOS+"0";			
				break;
			case "1":
				NUMEROS_INGRESADOS=NUMEROS_INGRESADOS+"1";			
				break;
			case "2":
				NUMEROS_INGRESADOS=NUMEROS_INGRESADOS+"2";			
				break;
			case "3":
				NUMEROS_INGRESADOS=NUMEROS_INGRESADOS+"3";			
				break;
			case "4":
				NUMEROS_INGRESADOS=NUMEROS_INGRESADOS+"4";			
				break;
			case "5":
				NUMEROS_INGRESADOS=NUMEROS_INGRESADOS+"5";
				break;

			case "6":
				NUMEROS_INGRESADOS=NUMEROS_INGRESADOS+"6";
				break;
			case "7":
				NUMEROS_INGRESADOS=NUMEROS_INGRESADOS+"7";
				break;
			case "8":
				NUMEROS_INGRESADOS=NUMEROS_INGRESADOS+"8";
				break;
			case "9":
				NUMEROS_INGRESADOS=NUMEROS_INGRESADOS+"9";
				break;
			default:
				// statements_def
				break;
	}
	
	if(NUMEROS_INGRESADOS.length<9){ /// imprimimos los numeros hasta una logitud de 9
		pantalla.innerHTML=NUMEROS_INGRESADOS;

		Expre+=NUMEROS_INGRESADOS;
				

	}
	
}



// funcion que evalua una exprecion 
function total(){
	
	var resultado=eval(Expre);
	pantalla.innerHTML=resultado;
	document.getElementById("resultado").innerHTML=resultado;

	
}
	
	


